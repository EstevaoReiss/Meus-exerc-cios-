<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5</title>
    <script src="../JS/exer5.js"></script>
</head>
<body>
    <h2>Digite suas notas para saber sua média</h2>
    
    <form method="post">
    <label for="n1">Comprimento:</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">Altura:</label><br>
    <input type="text" name="n2" id="n2"><br><br>
    <label for="n3">Largura:</label><br>
    <input type="text" name="n3" id="n3"><br><br>

    <input type="submit" name="btn">
    </form>

    <?php
        if (isset($_POST['btn'])){
            $n1 = $_POST['n1'];
            $n2 = $_POST['n2'];
            $n3 = $_POST['n3'];
                
            function calc($a1,$a2,$a3){
                return $a1 * $a2 * $a3;
            }

                echo "<h3><br><br> O Volume da caixa é de ".calc($n1,$n2,$n3)." m<sup>3</sup></h3>";
            }
        ?>

</body>
</html>