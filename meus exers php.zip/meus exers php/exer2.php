<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2</title>
    <script src="../JS/exer2.js"></script>
</head>
<body>
    <h2>Digite os números para calcular a soma de seus quadrados</h2>
    
    <form method="post">
    <label for="n1">Primeiro Número:</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">Segundo Número:</label><br>
    <input type="text" name="n2" id="n2"><br><br>
    
    <input type="submit" name="btn">

    <?php
        if (isset($_POST['btn'])){
            $n1 = $_POST['n1'];
            $n2 = $_POST['n2'];
            function calc($a1,$a2){
                return ($a1 * $a1) + ($a2 * $a2);
            }

            echo "<h3><br><br> A soma dos quadrados é: ".calc($n1,$n2)."</h3>";
            }
    ?>
    </form>

</body>
</html>