<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3</title>
    <script src="../JS/exer3.js"></script>
</head>
<body>
    <h2>Digite suas notas para saber sua média</h2>
    
    <form method="post">
    <label for="n1">Nota 1:</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">Nota 2:</label><br>
    <input type="text" name="n2" id="n2"><br><br>
    <label for="n3">Nota 3:</label><br>
    <input type="text" name="n3" id="n3"><br><br>

    <input type="submit" name="btn">
    
    <?php
        if (isset($_POST['btn'])){
            $n1 = $_POST['n1'];
            $n2 = $_POST['n2'];
            $n3 = $_POST['n3'];
            function calc($a1,$a2,$a3){
                return ($a1 * 0.2) + ($a2 * 0.3) + ($a3 * 0.5);
            }

            echo "<h3><br><br> A sua media é de: ".calc($n1,$n2,$n3)."</h3>";
        }
    ?>
    </form>

</body>
</html>