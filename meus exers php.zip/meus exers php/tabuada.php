<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabuada</title>
    <style>
     
    {
     
      background-color: purple;  
    }
    #container {
        padding: 15px;
        width: 50vh;
        margin: 0 auto;
        text-align: center;
    }
    table, tr, td {
        
        border: 1px solid black;
        margin: 0 auto;
        background-color: white;
    }
    </style>
</head>
<body>
    <div id="container">
    
    <form method="post">
        <h1>qual numero deseja a Tabuada?</h1>
        <input type="text" name="n1"><br><br>
        <input type="submit" value="calcular" name="tab">
    </form>

    <?php
            
            if (isset($_POST['tab'])){
                
            $n1 = $_POST['n1'];
            
            echo "<table>";
            for ($c=1;$c<=10;$c++) { 
                $t = $n1 * $c;
                echo "<tr>";
                echo "<p>"."<td>"."<h5>".$n1."X".$c."=".$t."</p> <br> </h5></td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    ?>
    
    </div>
</body>
</html>