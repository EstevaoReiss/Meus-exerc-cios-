<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4</title>
    <script src="../JS/exer4.js"></script>
</head>
<body>
    <h2>Digite suas notas para saber sua média</h2>
    
    <form method="post">
    <label for="n1">Distância em KM:</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">Quantidade de combustível em Litros a ser consumida:</label><br>
    <input type="text" name="n2" id="n2"><br><br>

    <input type="submit" name="btn">

    <?php
        if (isset($_POST['btn'])){
            $n1 = $_POST['n1'];
            $n2 = $_POST['n2'];
            function calc($a1,$a2){
                return $a1 / $a2;
            }

            echo "<h3><br><br> O consumo médio será de ".calc($n1,$n2)." litros</h3>";
            }
    ?>
    </form>
</body>
</html>