<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post">
    <label for="n1">digite a altura</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">digite a largura</label><br>
    <input type="text" name="n2" id="n2"><br><br>
    <label for="n3">digite o comprimento </label><br>
    <input type="text" name="n3" id="n3"><br><br>
    
    <input type="submit" name="btn"> 
    <?php
       if (isset($_POST['n1'])and isset($_POST['n2'])and isset($_POST['n3'])){
        $n1 = $_POST['n1'];
        $n2 = $_POST['n2'];
        $n3 = $_POST['n3'];
        $volume = $n1*$n2*$n3;
        echo $volume;
       }
    ?>
</body>
</html>