<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Digite as variaveis</h2>
    
    <form method="post">
        <label for="val1">digite a variavel 1:</label><br>
        <input type="text" name="val1" id="val1"><br><br>
        
        <input type="submit" name="btn">

        <?php
                $val1 = $_POST['val1'];{

                echo '15% do valor digitado é:'.$val1*0.15;
            }
        ?>
</body>
</html>