<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>Digite os números para calcular a soma</h2>
    
    <form method="post">
    <label for="n1">Primeiro Número:</label><br>
    <input type="text" name="n1" id="n1"><br><br>
    <label for="n2">Segundo Número:</label><br>
    <input type="text" name="n2" id="n2"><br><br>
    
    <input type="submit" name="btn">

    <?php
        if (isset($_POST['n1'])and isset($_POST['n2'])){
            $N1 = $_POST['n1'];
            $N2 = $_POST['n2'];
        $soma= ($N1+$N2)*$N1;
        echo 'a resultado é:'. $soma;
 }
    
    ?>
    </form>

</body>
</html>