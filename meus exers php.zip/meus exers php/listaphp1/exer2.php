<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Digite as variaveis</h2>
    
    <form method="post">
        <label for="val1">digite a variavel 1:</label><br>
        <input type="text" name="val1" id="val1"><br><br>
        <label for="val2">digite a variavel 2:</label><br>
        <input type="text" name="val2" id="val2"><br><br>
        <label for="val3">digite a variavel 3</label><br>
        <input type="text" name="val3" id="val3"><br><br>

        <input type="submit" name="btn">

        <?php
            if (isset($_POST['btn'])){
                $n1 = $_POST['val1'];
                $n2 = $_POST['val2'];
                $n3 = $_POST['val3'];
                
                function calc($val1,$val2,$val3){
                    return ($val1 + $val2 + $val3) / 3;
                }

                echo "<h3><br><br> a média é de ".calc($n1,$n2,$n3)."</h3>";
            }
        ?>

    </form>
    
</body>
</html>